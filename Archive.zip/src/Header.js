import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import AccountCircle from "@mui/icons-material/AccountCircle";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import EmailIcon from "@mui/icons-material/Email";
import NotificationsIcon from "@mui/icons-material/Notifications";
import Grid from "@mui/material/Grid";
import Avatar from "@mui/material/Avatar";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import SearchIcon from "@mui/icons-material/Search"; 
import InputAdornment from "@mui/material/InputAdornment"; 

const Header = ({ sidebarOpen }) => {
  const [searchText, setSearchText] = React.useState("");

  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };

  const iconColor = "#9e86e4";
  const profilePicUrl = "https://media.licdn.com/dms/image/v2/D4E16AQEFy1wCiDE95A/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1715240496822?e=2147483647&v=beta&t=3BZewgxqnThNWlCRezwmH72P8H2TEnB16TdsivzWL8k";
  const userName = "L Bhaskar Reddy"; 

  return (
    <Grid container sx={{ position: "relative", minHeight: "1vh" }}>
      <Grid
        item
        xs={12}
        sx={{
          position: "relative",
          top: 0,
          zIndex: 1,
          width: "100%",
          marginLeft: sidebarOpen ? 240 : 0,
          transition: "margin-left 0.5s ease",
        }}
      >
        <AppBar
          position="static"
          sx={{
            backgroundColor: "white",
            height: 100,
            borderRadius: "10px",
            boxShadow: 2,
          }}
        >
          <Toolbar
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            {/* Username displayed before search bar */}
            <Typography
              variant="h6"
              component="div"
              sx={{
                color: "black",
                fontWeight: "bold",
                fontFamily: '"Roboto", "Arial", sans-serif',
                marginLeft: "240px", 
              }}
            >
              Hello, {userName} 👋
            </Typography>

            {/* Search bar centered */}
            <Box
              sx={{ flexGrow: 1, display: "flex", justifyContent: "center" }}
            >
              <TextField
                variant="outlined"
                size="small"
                value={searchText}
                onChange={handleSearchChange}
                placeholder="Search your Products"
                fullWidth
                sx={{
                  maxWidth: 500,
                  borderRadius: "30px",
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "30px",
                  },
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ color: iconColor }} />
                    </InputAdornment>
                  ),
                }}
              />
            </Box>

            {/* Right section with icons and profile */}
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <IconButton
                size="large"
                aria-label="notifications"
                color="inherit"
              >
                <NotificationsIcon sx={{ color: iconColor }} />
              </IconButton>

              <IconButton size="large" aria-label="messages" color="inherit">
                <EmailIcon sx={{ color: iconColor }} />
              </IconButton>

              {/* Account Profile Section */}
              <Box sx={{ display: "flex", alignItems: "center" }}>
                {/* Avatar for profile picture */}
                <Avatar
                  src={profilePicUrl}
                  alt={userName}
                  sx={{
                    width: 40,
                    height: 40,
                    marginRight: 1,
                    border: `2px solid ${iconColor}`,
                  }}
                />
                <Typography
                  variant="body1"
                  sx={{
                    color: "black",
                    marginRight: 1,
                    fontWeight: "bold",
                    fontFamily: '"Roboto", "Arial", sans-serif',
                  }}
                >
                  {userName}
                </Typography>

                {/* Down Arrow Icon */}
                <IconButton size="small" aria-label="show more" color="inherit">
                  <KeyboardArrowDownIcon sx={{ color: iconColor }} />
                </IconButton>
              </Box>
            </Box>
          </Toolbar>
        </AppBar>
      </Grid>

      {/* Content or other components */}
      <Grid item xs={12} sx={{ padding: 3 }}>
        {/* Your page content goes here */}
      </Grid>
    </Grid>
  );
};

export default Header;