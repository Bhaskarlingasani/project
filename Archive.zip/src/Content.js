import React from "react";
import {
  Box,
  Grid,
  Typography,
  Card,
  CardContent,
  Divider,
  Avatar,
} from "@mui/material";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { BarChart, Bar } from "recharts";

// Material UI Icons
import PeopleIcon from "@mui/icons-material/People";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ShoppingBagIcon from "@mui/icons-material/ShoppingBag";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";

// Order data with product ID
const orders = [
  {
    productId: "#P001",
    orderId: "#202394",
    customer: "Ripon Ahmed",
    date: "1 Jan 24",
    price: 1200,
    status: "Completed",
  },
  {
    productId: "#P002",
    orderId: "#202395",
    customer: "Darlene Robertson",
    date: "2 Jan 24",
    price: 1800,
    status: "Pending",
  },
  {
    productId: "#P003",
    orderId: "#202396",
    customer: "Leslie Alexander",
    date: "3 Jan 24",
    price: 500,
    status: "Completed",
  },
  {
    productId: "#P004",
    orderId: "#202397",
    customer: "Ralph Edwards",
    date: "4 Jan 24",
    price: 2500,
    status: "Completed",
  },
  {
    productId: "#P005",
    orderId: "#202398",
    customer: "Ronald Richards",
    date: "6 Jan 24",
    price: 700,
    status: "Pending",
  },
];
const clothingAvatars = [
  "https://media.istockphoto.com/id/1480998820/photo/a-pile-of-well-cleaned-used-jeans-on-a-white-background.jpg?s=2048x2048&w=is&k=20&c=5SHY-7ZHUIAn-iKOxSG7Eom5xdyUZg1miIYlpKtMqQ4=", // Blue jeans
  "https://media.istockphoto.com/id/2156609312/photo/street-style-fashion-cloth-of-beige-brown-mens-coat-classy-urban-outerwear.jpg?s=2048x2048&w=is&k=20&c=lq7GRbV9DMIDCl2efvAJX_8wGpVqUocDVVbWOpel6gE=", // Red jacket
  "https://media.istockphoto.com/id/1671258160/photo/sweatshirt.jpg?s=2048x2048&w=is&k=20&c=aUZNispaZ0YXSf-7luzidvew_mTsqVZkbpR6Fnb6JNU=", // Orange sweater
  "https://media.istockphoto.com/id/483960103/photo/blank-black-t-shirt-front-with-clipping-path.jpg?s=2048x2048&w=is&k=20&c=_DzY2SQt7vIWPn7ONt9uk6-hM8Evo-i36ChVKIaDngo=", // Green t-shirt
  "https://media.istockphoto.com/id/1451763647/photo/blue-baseball-cap.jpg?s=2048x2048&w=is&k=20&c=7x_B6SRlAT5IQfmwym7WEV4A-dx5T0Dlvo7vg8VZhmE=", // Yellow cap
];

//the mapping of product to images based on `orders` data
const productAvatars = {
    "#P001": clothingAvatars[0],
    "#P002": clothingAvatars[1],
    "#P003": clothingAvatars[2],
    "#P004": clothingAvatars[3],
    "#P005": clothingAvatars[4],
  };

// Top Sold Items data with assigned colors
const topSoldItems = [
  { name: "Jeans", percentage: 75, color: "#5A5DF9" }, // Blue
  { name: "Jacket", percentage: 90, color: "#F95A5A" }, // Red
  { name: "Sweater", percentage: 80, color: "#FF9F00" }, // Orange
  { name: "T-Shirt", percentage: 60, color: "#2ECC71" }, // Green
  { name: "Cap", percentage: 50, color: "#F5A623" }, // Yellow
];

// Sales Trend Data
const salesTrendData = [
  { month: "January", current: 10, last: 5 },
  { month: "March", current: 30, last: 20 },
  { month: "May", current: 20, last: 15 },
  { month: "July", current: 40, last: 35 },
  { month: "September", current: 30, last: 25 },
  { month: "December", current: 20, last: 15 },
];

// Product Views Data
const productViewsData = [
  { day: "Sun", thisWeek: 8, lastWeek: 6 },
  { day: "Mon", thisWeek: 12, lastWeek: 10 },
  { day: "Tue", thisWeek: 14, lastWeek: 12 },
  { day: "Wed", thisWeek: 16, lastWeek: 14 },
  { day: "Thu", thisWeek: 10, lastWeek: 8 },
  { day: "Fri", thisWeek: 14, lastWeek: 12 },
  { day: "Sat", thisWeek: 12, lastWeek: 10 },
];

const productIcons = {
  "#P001": <PeopleIcon />,
  "#P002": <PeopleIcon />,
  "#P003": <PeopleIcon />,
  "#P004": <PeopleIcon />,
  "#P005": <PeopleIcon />,
};

const Content = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        padding: 3,
        width: "calc(100% - 240px)", // Adjust width based on the sidebar
        marginLeft: "240px", //  starts after sidebar
      }}
    >
      <Grid container spacing={3}>
        {/* Summary Cards with Icons */}
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <PeopleIcon
                  sx={{ fontSize: 40, color: "#5A5DF9", marginRight: 1 }}
                />
                <Box>
                  <Typography variant="h6" color="primary">
                    2000+
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Customers
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <ShoppingCartIcon
                  sx={{ fontSize: 40, color: "#F95A5A", marginRight: 1 }}
                />
                <Box>
                  <Typography variant="h6" color="primary">
                    140+
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Products
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <ShoppingBagIcon
                  sx={{ fontSize: 40, color: "#F5A623", marginRight: 1 }}
                />
                <Box>
                  <Typography variant="h6" color="primary">
                    1600+
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Orders
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <AttachMoneyIcon
                  sx={{ fontSize: 40, color: "#2ECC71", marginRight: 1 }}
                />
                <Box>
                  <Typography variant="h6" color="primary">
                    2000+
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Sales
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Sales Trend Chart (LineChart with Recharts) */}
        <Grid item xs={12} md={8}>
  <Card>
    <CardContent>
      <Typography variant="h6">Sales Trend</Typography>
      <Box sx={{ pt: 2, height: "300px" }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={salesTrendData}>
            <CartesianGrid strokeDasharray="3 3" />
            
            {/* Hide the X and Y axis lines but keep the ticks visible */}
            <XAxis 
              dataKey="month" 
              axisLine={false} 
              tickLine={false} 
            />
            <YAxis
              tickFormatter={(value) => `${value}k`} 
              domain={[0, 60]} 
              ticks={[0, 10, 20, 30, 40, 50, 60]} 
              axisLine={false} 
              tickLine={false} 
            />
            
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="current" stroke="#5A5DF9" />
            <Line type="monotone" dataKey="last" stroke="#F95A5A" />
          </LineChart>
        </ResponsiveContainer>
      </Box>
    </CardContent>
  </Card>
</Grid>



        {/* Product Views Chart (BarChart with Recharts) */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Product Views</Typography>
              <Box sx={{ pt: 1, height: "300px" }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productViewsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis
                      tickFormatter={(value) => `${value}k`} 
                      domain={[0, 16]} 
                      ticks={[0, 2, 4, 6, 8, 10, 12, 14, 16]} 
                    />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="thisWeek" fill="#5A5DF9" />
                    <Bar dataKey="lastWeek" fill="#F95A5A" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
{/* All Orders Table */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6">All Orders</Typography>
              <Divider sx={{ my: 1}} />

              {/* Table header */}
              <Grid
                container
                spacing={1}
                sx={{ fontWeight: "bold", marginBottom: 5 }}
              >
                <Grid item xs={2}>
                  <Typography>Product</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Typography>Order ID</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Typography>Customer</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Typography>Date</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Typography>Price</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Typography>Status</Typography>
                </Grid>
              </Grid>

              {/* Order data */}
              {orders.map((order) => (
                <Grid
                  container
                  spacing={1}
                  key={order.orderId}
                  sx={{ marginBottom: 6.60 }}
                >
                  <Grid item xs={2}>
                    <Avatar
                      alt={order.productId}
                      src={productAvatars[order.productId]}
                    />
                  </Grid>
                  <Grid item xs={2}>
                    <Typography>{order.orderId}</Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography>{order.customer}</Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography>{order.date}</Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography>Tk {order.price}</Typography>
                  </Grid>
                  <Grid item xs={2}>
                    <Typography
                      sx={{
                        color: order.status === "Completed" ? "green" : "red",
                      }}
                    >
                      {order.status}
                    </Typography>
                  </Grid>
                </Grid>
              ))}
            </CardContent>
          </Card>
        </Grid>


        {/* Top Sold Items */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Top Sold Items</Typography>
              <Divider sx={{ my: 5.5 }} />

              {/* Top Sold Items Grid */}
              <Grid
                container
                spacing={2}
                direction="column"
                alignItems="flex-start"
              >
                {topSoldItems.map((item) => (
                  <Grid item key={item.name} sx={{ width: "100%" }}>
                    <Typography variant="h6" sx={{ mb: 1 }}>
                      {item.name}
                    </Typography>
                    <Box
                      sx={{
                        backgroundColor: item.color,
                        width: `${item.percentage}%`, // Fixed this line
                        height: 10,
                        borderRadius: "5px",
                      }}
                    />
                    <Typography variant="body2" sx={{ mt: 1 }}>
                      {item.percentage}%
                    </Typography>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Content;