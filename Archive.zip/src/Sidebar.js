import * as React from 'react';
import { useState } from 'react';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import HomeIcon from '@mui/icons-material/Home';
import PersonIcon from '@mui/icons-material/Person';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import PaymentIcon from '@mui/icons-material/Payment';
import ShoppingBagIcon from '@mui/icons-material/ShoppingBag';
import ChatIcon from '@mui/icons-material/Chat';
import MailIcon from '@mui/icons-material/Mail';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import BrandingWatermarkIcon from '@mui/icons-material/BrandingWatermark';
import SettingsIcon from '@mui/icons-material/Settings';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import Divider from '@mui/material/Divider';
import StorefrontIcon from '@mui/icons-material/Storefront';  
 
const Sidebar = () => {
  const [open, setOpen] = useState(true);
 
  return (
    <Drawer
      sx={{
        width: 240,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 240,
          boxSizing: 'border-box',
        },
      }}
      variant="persistent"
      anchor="left"
      open={open}
    >
      <List>
        <ListItem sx={{ paddingY: 6, display: 'flex', alignItems: 'center', backgroundColor: 'white' }}>
          <ListItemIcon sx={{ color: '#457bd1' }}>
            <StorefrontIcon />
          </ListItemIcon>
          <ListItemText primary="E-commerce" sx={{ color: 'black', fontStyle: 'normal' }} />
        </ListItem>
 
        <Divider sx={{ marginY: 6 }} />
 
        {/* List Items with custom hover effect using #457bd1 */}
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <HomeIcon />
          </ListItemIcon>
          <ListItemText primary="Dashboard" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <PersonIcon />
          </ListItemIcon>
          <ListItemText primary="Customer" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <ShoppingCartIcon />
          </ListItemIcon>
          <ListItemText primary="Products" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <PaymentIcon />
          </ListItemIcon>
          <ListItemText primary="Payments" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <ShoppingBagIcon />
          </ListItemIcon>
          <ListItemText primary="Orders" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <ChatIcon />
          </ListItemIcon>
          <ListItemText primary="Chat" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <MailIcon />
          </ListItemIcon>
          <ListItemText primary="Mail" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <CalendarTodayIcon />
          </ListItemIcon>
          <ListItemText primary="Calendar" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <BrandingWatermarkIcon />
          </ListItemIcon>
          <ListItemText primary="Brands" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <Divider sx={{ marginY: 6 }} />
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <SettingsIcon />
          </ListItemIcon>
          <ListItemText primary="Settings" sx={{ color: 'inherit' }} />
        </ListItem>
 
        <ListItem
          button
          sx={{
            '&:hover': { backgroundColor: '#457bd1', color: 'white' },
          }}
        >
          <ListItemIcon sx={{ color: 'inherit' }}>
            <ExitToAppIcon />
          </ListItemIcon>
          <ListItemText primary="Logout" sx={{ color: 'inherit' }} />
        </ListItem>
      </List>
    </Drawer>
  );
};
 
export default Sidebar;