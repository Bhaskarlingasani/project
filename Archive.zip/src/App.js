import * as React from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import { Grid} from "@mui/material";
import Content from "./Content";
import "./App.css";

const App = () => {
  return (
    <div>
      <Grid
        sx={{
          padding: 1,
          borderRadius: "60px",
          overflow: "hidden",
          backgroundColor: "#EAEBED",
        }}
      >
        <Grid>
          <Header />
        </Grid>
        <Grid>
          <Sidebar />
        </Grid>
        <Grid>
          <Content />
        </Grid>
      </Grid>
    </div>
  );
};

export default App;